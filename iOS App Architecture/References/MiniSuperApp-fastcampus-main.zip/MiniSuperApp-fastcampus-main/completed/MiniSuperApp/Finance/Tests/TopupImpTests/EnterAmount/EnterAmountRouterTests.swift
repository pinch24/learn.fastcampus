@testable import TopupImp
import XCTest

final class EnterAmountRouterTests: XCTestCase {
  
  private var router: EnterAmountRouter!
  
  override func setUp() {
    super.setUp()
    
  }
  
}
