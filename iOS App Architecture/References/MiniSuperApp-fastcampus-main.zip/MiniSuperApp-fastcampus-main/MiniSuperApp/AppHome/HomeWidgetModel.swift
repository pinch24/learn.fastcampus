import Foundation

struct HomeWidgetModel {
  let imageName: String
  let title: String
  let tapHandler: () -> Void
}
