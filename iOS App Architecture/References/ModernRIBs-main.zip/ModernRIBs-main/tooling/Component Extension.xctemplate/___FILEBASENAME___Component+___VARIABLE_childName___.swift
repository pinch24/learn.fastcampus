//___FILEHEADER___

import ModernRIBs

/// The dependencies needed from the parent scope of ___VARIABLE_productName___ to provide for the ___VARIABLE_childName___ scope.
// TODO: Update ___VARIABLE_productName___Dependency protocol to inherit this protocol.
protocol ___VARIABLE_productName___Dependency___VARIABLE_childName___: Dependency {
    // TODO: Declare dependencies needed from the parent scope of ___VARIABLE_productName___ to provide dependencies
    // for the ___VARIABLE_childName___ scope.
}

extension ___VARIABLE_productName___Component: ___VARIABLE_childName___Dependency {

    // TODO: Implement properties to provide for ___VARIABLE_childName___ scope.
}
