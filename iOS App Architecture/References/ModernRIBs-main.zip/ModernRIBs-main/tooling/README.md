# RIBs Xcode Templates

We have created Xcode templates to generate RIBs scaffolding and test scaffolding, making RIBs usage and adoption easier. The scaffolded classes have RIBs wired up, ready to add business logic to them.

For details on installation and usage, please see the [iOS tooling wiki page](https://github.com/uber/RIBs/wiki/iOS-Tooling).
