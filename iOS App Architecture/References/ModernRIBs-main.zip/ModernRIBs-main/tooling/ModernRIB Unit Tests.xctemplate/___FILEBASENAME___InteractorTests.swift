//___FILEHEADER___

@testable import ___PROJECTNAME___
import XCTest

final class ___VARIABLE_productName___InteractorTests: XCTestCase {

    private var interactor: ___VARIABLE_productName___Interactor!

    // TODO: declare other objects and mocks you need as private vars

    override func setUp() {
        super.setUp()

        // TODO: instantiate objects and mocks
    }

    // MARK: - Tests

    func test_exampleObservable_callsRouterOrListener_exampleProtocol() {
        // This is an example of an interactor test case.
        // Test your interactor binds observables and sends messages to router or listener.
    }
}
