//___FILEHEADER___

@testable import ___PROJECTNAME___
import XCTest

final class ___VARIABLE_productName___RouterTests: XCTestCase {

    private var router: ___VARIABLE_productName___Router!

    // TODO: declare other objects and mocks you need as private vars

    override func setUp() {
        super.setUp()

        // TODO: instantiate objects and mocks
    }

    // MARK: - Tests

    func test_routeToExample_invokesToExampleResult() {
        // This is an example of a router test case.
        // Test your router functions invokes the corresponding builder, attachesChild, presents VC, etc.
    }
}
